USE ecommerce_analytics;

-- 1. Total completed revenue
SELECT ROUND(SUM(oi.quantity * oi.unit_price),2) AS total_revenue
FROM order_items oi
JOIN orders o ON oi.order_id=o.order_id
WHERE o.status='Completed';

-- 2. Monthly revenue trend
SELECT DATE_FORMAT(o.order_date,'%Y-%m') AS month,
       ROUND(SUM(oi.quantity*oi.unit_price),2) AS revenue
FROM orders o JOIN order_items oi ON o.order_id=oi.order_id
WHERE o.status='Completed'
GROUP BY DATE_FORMAT(o.order_date,'%Y-%m')
ORDER BY month;

-- 3. Revenue by category
SELECT p.category, ROUND(SUM(oi.quantity*oi.unit_price),2) revenue
FROM products p
JOIN order_items oi ON p.product_id=oi.product_id
JOIN orders o ON oi.order_id=o.order_id
WHERE o.status='Completed'
GROUP BY p.category ORDER BY revenue DESC;

-- 4. Top customers
SELECT c.customer_id,c.name,
       COUNT(DISTINCT o.order_id) orders,
       ROUND(SUM(oi.quantity*oi.unit_price),2) revenue
FROM customers c
JOIN orders o ON c.customer_id=o.customer_id
JOIN order_items oi ON o.order_id=oi.order_id
WHERE o.status='Completed'
GROUP BY c.customer_id,c.name
ORDER BY revenue DESC LIMIT 10;

-- 5. Top products
SELECT p.product_id,p.product_name,p.category,
       SUM(oi.quantity) units,
       ROUND(SUM(oi.quantity*oi.unit_price),2) revenue
FROM products p
JOIN order_items oi ON p.product_id=oi.product_id
JOIN orders o ON oi.order_id=o.order_id
WHERE o.status='Completed'
GROUP BY p.product_id,p.product_name,p.category
ORDER BY revenue DESC LIMIT 10;

-- 6. Customer segmentation using RFM-style scores
WITH metrics AS (
    SELECT c.customer_id,c.name,
           DATEDIFF((SELECT MAX(order_date) FROM orders),
                    MAX(o.order_date)) recency_days,
           COUNT(DISTINCT o.order_id) frequency,
           ROUND(SUM(oi.quantity*oi.unit_price),2) monetary
    FROM customers c
    LEFT JOIN orders o ON c.customer_id=o.customer_id AND o.status='Completed'
    LEFT JOIN order_items oi ON o.order_id=oi.order_id
    GROUP BY c.customer_id,c.name
)
SELECT *,
       CASE
         WHEN frequency >= 8 AND monetary >= 100000 THEN 'VIP'
         WHEN frequency >= 4 THEN 'Loyal'
         WHEN frequency >= 1 THEN 'Active'
         ELSE 'Inactive'
       END AS segment
FROM metrics
ORDER BY monetary DESC;

-- 7. Window function: monthly revenue and month-over-month change
WITH monthly AS (
    SELECT DATE_FORMAT(o.order_date,'%Y-%m') month,
           SUM(oi.quantity*oi.unit_price) revenue
    FROM orders o JOIN order_items oi ON o.order_id=oi.order_id
    WHERE o.status='Completed'
    GROUP BY DATE_FORMAT(o.order_date,'%Y-%m')
)
SELECT month, ROUND(revenue,2) revenue,
       ROUND(LAG(revenue) OVER(ORDER BY month),2) previous_month,
       ROUND(revenue-LAG(revenue) OVER(ORDER BY month),2) revenue_change
FROM monthly ORDER BY month;

-- 8. Rank customers by revenue
SELECT customer_id,name,revenue,
       DENSE_RANK() OVER(ORDER BY revenue DESC) revenue_rank
FROM (
    SELECT c.customer_id,c.name,
           SUM(oi.quantity*oi.unit_price) revenue
    FROM customers c
    JOIN orders o ON c.customer_id=o.customer_id
    JOIN order_items oi ON o.order_id=oi.order_id
    WHERE o.status='Completed'
    GROUP BY c.customer_id,c.name
) x;

-- 9. Cohort analysis
WITH first_purchase AS (
    SELECT customer_id,
           DATE_FORMAT(MIN(order_date),'%Y-%m-01') cohort_month
    FROM orders
    WHERE status='Completed'
    GROUP BY customer_id
),
activity AS (
    SELECT DISTINCT customer_id,
           DATE_FORMAT(order_date,'%Y-%m-01') activity_month
    FROM orders
    WHERE status='Completed'
)
SELECT fp.cohort_month,a.activity_month,
       COUNT(DISTINCT a.customer_id) active_customers
FROM first_purchase fp
JOIN activity a ON fp.customer_id=a.customer_id
GROUP BY fp.cohort_month,a.activity_month
ORDER BY fp.cohort_month,a.activity_month;

-- 10. Retention percentage
WITH first_purchase AS (
    SELECT customer_id,
           DATE_FORMAT(MIN(order_date),'%Y-%m-01') cohort_month
    FROM orders WHERE status='Completed'
    GROUP BY customer_id
),
activity AS (
    SELECT DISTINCT customer_id,
           DATE_FORMAT(order_date,'%Y-%m-01') activity_month
    FROM orders WHERE status='Completed'
),
cohort_size AS (
    SELECT cohort_month,COUNT(*) cohort_customers
    FROM first_purchase GROUP BY cohort_month
)
SELECT fp.cohort_month,a.activity_month,
       COUNT(DISTINCT a.customer_id) active_customers,
       ROUND(COUNT(DISTINCT a.customer_id)*100.0/cs.cohort_customers,2) retention_pct
FROM first_purchase fp
JOIN activity a ON fp.customer_id=a.customer_id
JOIN cohort_size cs ON fp.cohort_month=cs.cohort_month
GROUP BY fp.cohort_month,a.activity_month,cs.cohort_customers
ORDER BY fp.cohort_month,a.activity_month;
