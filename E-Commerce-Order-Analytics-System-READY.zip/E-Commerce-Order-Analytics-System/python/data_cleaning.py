import pandas as pd
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
RAW = BASE / "data" / "raw"
CLEAN = BASE / "data" / "cleaned"
CLEAN.mkdir(parents=True, exist_ok=True)

customers = pd.read_csv(RAW/"customers.csv")
customers = customers.drop_duplicates("customer_id")
customers["email"] = customers["email"].fillna("unknown@example.com")
customers["name"] = customers["name"].astype(str).str.strip()
customers["city"] = customers["city"].astype(str).str.strip()
customers["signup_date"] = pd.to_datetime(customers["signup_date"], errors="coerce")
customers = customers.dropna(subset=["customer_id","signup_date"])
customers.to_csv(CLEAN/"customers_clean.csv", index=False, date_format="%Y-%m-%d")

products = pd.read_csv(RAW/"products.csv")
products = products.drop_duplicates("product_id")
products["category"] = products["category"].astype(str).str.strip().str.title()
products["price"] = pd.to_numeric(products["price"], errors="coerce")
products = products[products["price"] > 0].dropna(subset=["product_id","product_name","category","price"])
products.to_csv(CLEAN/"products_clean.csv", index=False)

orders = pd.read_csv(RAW/"orders.csv")
orders = orders.drop_duplicates("order_id")
orders["customer_id"] = pd.to_numeric(orders["customer_id"], errors="coerce")
orders["order_date"] = pd.to_datetime(orders["order_date"], errors="coerce")
orders["status"] = orders["status"].astype(str).str.strip().str.title()
orders = orders.dropna(subset=["order_id","customer_id","order_date","status"])
orders = orders[orders["customer_id"].isin(set(customers["customer_id"]))]
orders.to_csv(CLEAN/"orders_clean.csv", index=False, date_format="%Y-%m-%d")

items = pd.read_csv(RAW/"order_items.csv")
items = items.drop_duplicates("order_item_id")
for col in ["order_id","product_id","quantity","unit_price"]:
    items[col] = pd.to_numeric(items[col], errors="coerce")
items = items.dropna(subset=["order_item_id","order_id","product_id","quantity","unit_price"])
items = items[(items["quantity"] > 0) & (items["unit_price"] > 0)]
items = items[items["order_id"].isin(set(orders["order_id"]))]
items = items[items["product_id"].isin(set(products["product_id"]))]
items.to_csv(CLEAN/"order_items_clean.csv", index=False)

print("Cleaning completed successfully.")
