import pandas as pd
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
CLEAN = BASE / "data" / "cleaned"

customers = pd.read_csv(CLEAN/"customers_clean.csv")
products = pd.read_csv(CLEAN/"products_clean.csv")
orders = pd.read_csv(CLEAN/"orders_clean.csv")
items = pd.read_csv(CLEAN/"order_items_clean.csv")

checks = {
    "duplicate customers": customers.customer_id.duplicated().sum(),
    "duplicate products": products.product_id.duplicated().sum(),
    "duplicate orders": orders.order_id.duplicated().sum(),
    "duplicate order items": items.order_item_id.duplicated().sum(),
    "missing customer values": customers.isna().sum().sum(),
    "missing product values": products.isna().sum().sum(),
    "missing order values": orders.isna().sum().sum(),
    "missing item values": items.isna().sum().sum(),
    "invalid product prices": (products.price <= 0).sum(),
    "invalid quantities": (items.quantity <= 0).sum(),
    "invalid order customers": (~orders.customer_id.isin(customers.customer_id)).sum(),
    "invalid item orders": (~items.order_id.isin(orders.order_id)).sum(),
    "invalid item products": (~items.product_id.isin(products.product_id)).sum()
}

print("DATA VALIDATION REPORT")
print("=" * 50)
for name, value in checks.items():
    print(f"{name}: {value}")

if all(v == 0 for v in checks.values()):
    print("\nVALIDATION PASSED")
else:
    print("\nVALIDATION FAILED")
