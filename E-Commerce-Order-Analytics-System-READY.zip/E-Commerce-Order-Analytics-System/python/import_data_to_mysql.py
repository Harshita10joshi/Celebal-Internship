import pandas as pd
import mysql.connector
from getpass import getpass
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
CLEAN = BASE / "data" / "cleaned"

password = getpass("Enter MySQL root password: ")

conn = mysql.connector.connect(
    host="localhost", user="root", password=password,
    database="ecommerce_analytics"
)
cursor = conn.cursor()

def load(table, file, columns):
    df = pd.read_csv(file)
    df = df.where(pd.notna(df), None)
    placeholders = ", ".join(["%s"] * len(columns))
    query = f"INSERT INTO {table} ({', '.join(columns)}) VALUES ({placeholders})"
    rows = [tuple(row[c] for c in columns) for _, row in df.iterrows()]
    cursor.executemany(query, rows)
    conn.commit()
    print(f"{table}: {len(rows)} rows loaded")

# Clear in FK-safe order
cursor.execute("SET FOREIGN_KEY_CHECKS = 0")
for table in ["order_items", "orders", "products", "customers"]:
    cursor.execute(f"DELETE FROM {table}")
cursor.execute("SET FOREIGN_KEY_CHECKS = 1")
conn.commit()

load("customers", CLEAN/"customers_clean.csv",
     ["customer_id","name","email","city","signup_date"])
load("products", CLEAN/"products_clean.csv",
     ["product_id","product_name","category","price"])
load("orders", CLEAN/"orders_clean.csv",
     ["order_id","customer_id","order_date","status"])
load("order_items", CLEAN/"order_items_clean.csv",
     ["order_item_id","order_id","product_id","quantity","unit_price"])

print("\nIMPORT COMPLETED")
for table in ["customers","products","orders","order_items"]:
    cursor.execute(f"SELECT COUNT(*) FROM {table}")
    print(f"{table}: {cursor.fetchone()[0]} rows")

cursor.close()
conn.close()
