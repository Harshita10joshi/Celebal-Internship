import argparse
import mysql.connector
from getpass import getpass

def connect():
    return mysql.connector.connect(
        host="localhost",
        user="root",
        password=getpass("MySQL password: "),
        database="ecommerce_analytics"
    )

def main():
    parser = argparse.ArgumentParser(description="E-Commerce Order Analytics CLI")
    parser.add_argument("--report", choices=["summary","monthly","customers","products","retention"],
                        default="summary")
    args = parser.parse_args()

    conn = connect()
    cur = conn.cursor(dictionary=True)

    queries = {
        "summary": """
            SELECT
                ROUND(SUM(oi.quantity * oi.unit_price),2) AS revenue,
                COUNT(DISTINCT o.order_id) AS completed_orders,
                COUNT(DISTINCT o.customer_id) AS customers,
                ROUND(AVG(oi.quantity * oi.unit_price),2) AS avg_item_value
            FROM orders o
            JOIN order_items oi ON o.order_id = oi.order_id
            WHERE o.status = 'Completed'
        """,
        "monthly": """
            SELECT DATE_FORMAT(o.order_date,'%Y-%m') AS month,
                   ROUND(SUM(oi.quantity*oi.unit_price),2) AS revenue,
                   COUNT(DISTINCT o.order_id) AS orders
            FROM orders o
            JOIN order_items oi ON o.order_id=oi.order_id
            WHERE o.status='Completed'
            GROUP BY DATE_FORMAT(o.order_date,'%Y-%m')
            ORDER BY month
        """,
        "customers": """
            SELECT c.customer_id, c.name,
                   COUNT(DISTINCT o.order_id) AS orders,
                   ROUND(SUM(oi.quantity*oi.unit_price),2) AS revenue
            FROM customers c
            LEFT JOIN orders o ON c.customer_id=o.customer_id AND o.status='Completed'
            LEFT JOIN order_items oi ON o.order_id=oi.order_id
            GROUP BY c.customer_id,c.name
            ORDER BY revenue DESC
            LIMIT 10
        """,
        "products": """
            SELECT p.product_id,p.product_name,p.category,
                   SUM(oi.quantity) AS units,
                   ROUND(SUM(oi.quantity*oi.unit_price),2) AS revenue
            FROM products p
            JOIN order_items oi ON p.product_id=oi.product_id
            JOIN orders o ON oi.order_id=o.order_id
            WHERE o.status='Completed'
            GROUP BY p.product_id,p.product_name,p.category
            ORDER BY revenue DESC
            LIMIT 10
        """,
        "retention": """
            WITH first_purchase AS (
                SELECT customer_id, DATE_FORMAT(MIN(order_date),'%Y-%m-01') cohort_month
                FROM orders WHERE status='Completed'
                GROUP BY customer_id
            ),
            activity AS (
                SELECT DISTINCT customer_id, DATE_FORMAT(order_date,'%Y-%m-01') activity_month
                FROM orders WHERE status='Completed'
            )
            SELECT fp.cohort_month, a.activity_month,
                   COUNT(DISTINCT a.customer_id) active_customers
            FROM first_purchase fp
            JOIN activity a ON fp.customer_id=a.customer_id
            GROUP BY fp.cohort_month,a.activity_month
            ORDER BY fp.cohort_month,a.activity_month
        """
    }

    cur.execute(queries[args.report])
    rows = cur.fetchall()

    if not rows:
        print("No data available for this report.")
    else:
        for row in rows:
            print(row)

    cur.close()
    conn.close()

if __name__ == "__main__":
    main()
