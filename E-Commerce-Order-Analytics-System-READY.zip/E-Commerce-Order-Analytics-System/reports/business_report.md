# Business Insights Report

## Key KPIs
The SQL layer calculates:
- Total completed revenue
- Completed order count
- Active customer count
- Average order/item value

## Revenue Analysis
Monthly revenue trends help identify growth, decline and seasonal patterns.

## Customer Analysis
Customers are segmented into VIP, Loyal, Active and Inactive groups using order frequency and monetary contribution.

## Product Analysis
Top products and categories are ranked by units sold and revenue.

## Cohort and Retention Analysis
Customers are grouped by their first purchase month. Monthly active customers and retention percentages are calculated to evaluate customer loyalty.

## Reliability
The pipeline validates duplicates, nulls, invalid prices/quantities and foreign-key integrity before loading data into MySQL.
