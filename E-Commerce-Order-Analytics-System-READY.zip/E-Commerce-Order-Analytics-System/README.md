# E-Commerce Order Analytics System

## Project Overview
An end-to-end e-commerce analytics system built with Python, Pandas and MySQL. The project generates realistic order data with intentional inconsistencies, cleans and validates the data, loads it into a relational database, and performs business analytics using joins, aggregations, CTEs, window functions, customer segmentation and cohort/retention analysis.

## Architecture
Raw CSV -> Pandas Cleaning -> Validation -> MySQL -> SQL Analytics -> CLI Reports

## Dataset
- customers
- products
- orders
- order_items

The raw data intentionally contains duplicate records, missing values, invalid prices, inconsistent category formatting, invalid foreign keys and invalid quantities.

## Data Cleaning
- Removed duplicates using business keys.
- Handled missing values.
- Standardized text/category values.
- Converted dates and numeric columns.
- Removed invalid prices and quantities.
- Validated foreign-key relationships.

## SQL Analytics
- Revenue trends
- Category performance
- Top customers/products
- Customer segmentation
- CTE-based analysis
- Window functions and ranking
- Cohort analysis
- Retention metrics

## CLI Reporting Tool
Run:
```bash
python python/reporting_tool.py --report summary
python python/reporting_tool.py --report monthly
python python/reporting_tool.py --report customers
python python/reporting_tool.py --report products
python python/reporting_tool.py --report retention
```

## Setup
```bash
pip install -r requirements.txt
```

Create the database/tables by running `sql/create_tables.sql` in MySQL Workbench.

Then load cleaned CSVs:
```bash
python python/import_data_to_mysql.py
```

Enter your local MySQL root password when prompted.

## Validation
```bash
python python/validation.py
```

## Project Structure
```text
E-Commerce-Order-Analytics-System/
├── data/
│   ├── raw/
│   └── cleaned/
├── python/
│   ├── generate_data.py
│   ├── data_cleaning.py
│   ├── validation.py
│   ├── import_data_to_mysql.py
│   └── reporting_tool.py
├── sql/
│   ├── create_tables.sql
│   └── analytics_queries.sql
├── reports/
│   └── business_report.md
├── requirements.txt
└── README.md
```
